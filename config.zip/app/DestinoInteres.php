<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DestinoInteres extends Model
{
    //
}
