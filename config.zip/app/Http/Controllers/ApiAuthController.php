<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use JWTAuth;

class ApiAuthController extends Controller
{
    public function userAuth(Request $request){
        $credentials = $request->only('email','password');
        $token=null;

        try{
            if(!$token=JWTAuth::attempt($credentials)){
                return response()->json(['error'=>'credenciales inválidas']);
            }
        }catch(JWTException $ex){
            return response()->json(['error'=>'ocurrio un error'],500);
        }
        $username=$token;
        return response()->json(compact('username'));
    }
}
