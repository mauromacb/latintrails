<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Itinerario extends Model
{
    protected $table = 'itinerario';
    protected $primaryKey = 'id_itinerario';
    public $timestamps = false;
}
