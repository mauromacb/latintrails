<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TipoAlojamiento extends Model
{
    //
}
